SCENARIODOSSIER

Project: Merwedekanaalzone
Scenario: Groen & Gezond 2040
Exportmoment (UTC): 2026-11-16T18:29:45.010885+00:00

Open rapport/dossierrapport.html voor een leesbaar overzicht. Open gis/scenario.gpkg in QGIS of ArcGIS Pro. Zie de projectdocumentatie voor de volledige werkinstructie. Controleer metadata/manifest-sha256.txt om bestandsintegriteit vast te stellen.
