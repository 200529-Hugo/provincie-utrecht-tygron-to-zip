"""Open de lokale CRS-proef. Start dit script vanuit de ScenarioDossier-repo."""

import argparse
import sys
from pathlib import Path
from tempfile import TemporaryDirectory

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', type=int, default=54881)
    args = parser.parse_args()

    repo = Path.cwd()
    if not (repo / 'scenario_dossier' / 'web.py').is_file():
        parser.error('Start dit script vanuit de ScenarioDossier-projectmap.')
    sys.path.insert(0, str(repo))
    from scenario_dossier.services.demo_service import DemoService
    from scenario_dossier.web import create_app

    with TemporaryDirectory(prefix='scenario-crs81-') as directory:
        work = Path(directory)
        app = create_app({
            'EXPORT_DIR': work / 'exports',
            'THUMBNAIL_CACHE_DIR': work / 'thumbnails',
            'MAP_STYLE_URL': '',
        })
        demo = DemoService(Path(__file__).with_name('demo-crs81.json'))
        controllers = app.extensions['controllers']
        controllers['projects'].demo = demo
        controllers['workflow'].service.demo = demo
        app.run(host='127.0.0.1', port=args.port, debug=False)


if __name__ == '__main__':
    main()
